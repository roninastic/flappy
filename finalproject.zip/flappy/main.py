import random  
import sys  
import pygame
from pygame.locals import *  
  
  
  # Global Variables for the game
FPS = 30
S_WIDTH = 289
S_HEIGHT = 511
SCREEN = pygame.display.set_mode((S_WIDTH, S_HEIGHT))
GROUNDY = S_HEIGHT * 0.8
G_SPRITE = {}
G_SOUND = {}
PLAYER = 'gallery/sprites/bird.png'
BACKGROUND = 'gallery/sprites/background.png'
PIPE = 'gallery/sprites/pipe.png'

def welcomeScreen():

    playerx = int(S_WIDTH / 5)
    playery = int((S_HEIGHT - G_SPRITE['player'].get_height()) / 2)
    messagex = int((S_WIDTH - G_SPRITE['message'].get_width()) / 2)
    messagey = int(S_HEIGHT * 0.13)
    basex = 0
    while True:
        for event in pygame.event.get():
            # close the game
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()

            # start the game 
            elif event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                return
            else:
                SCREEN.blit(G_SPRITE['background'], (0, 0))
                SCREEN.blit(G_SPRITE['player'], (playerx, playery))
                SCREEN.blit(G_SPRITE['message'], (messagex, messagey))
                SCREEN.blit(G_SPRITE['base'], (basex, GROUNDY))
                pygame.display.update()
                FPSCLOCK.tick(FPS)

def mainGame():
    score = 0
    playerx = int(S_WIDTH / 5)
    playery = int(S_WIDTH / 2)
    basex = 0

    # Creating 2 pipes for blitting on the screen
    newPipe1 = getRandomPipe()
    newPipe2 = getRandomPipe()

    #the List of upper pipes
    upperPipes = [
        {'x': S_WIDTH + 200, 'y': newPipe1[0]['y']},
        {'x': S_WIDTH + 200 + (S_WIDTH / 2), 'y': newPipe2[0]['y']},
    ]
    #the List of lower pipes
    lowerPipes = [
        {'x': S_WIDTH + 200, 'y': newPipe1[1]['y']},
        {'x': S_WIDTH + 200 + (S_WIDTH / 2), 'y': newPipe2[1]['y']},
    ]

    pipeVelX = -4

    playerVelY = -9
    playerMaxVelY = 10
    playerMinVelY = -8
    playerAccY = 1

    playerFlapAccv = -8  # velocity while flapping
    playerFlapped = False  # It is true only when the bird is flapping

    while True:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                if playery > 0:
                    playerVelY = playerFlapAccv
                    playerFlapped = True
                    G_SOUND['wing'].play()

        crashTest = isCollide(playerx, playery, upperPipes,
                              lowerPipes)  # This function will return true if the player is crashed
        if crashTest:
            return

            # check for score
        playerMidPos = playerx + G_SPRITE['player'].get_width() / 2
        for pipe in upperPipes:
            pipeMidPos = pipe['x'] + G_SPRITE['pipe'][0].get_width() / 2
            if pipeMidPos <= playerMidPos < pipeMidPos + 4:
                score += 1
                print(f"Your score is {score}")
                G_SOUND['point'].play()

        if playerVelY < playerMaxVelY and not playerFlapped:
            playerVelY += playerAccY

        if playerFlapped:
            playerFlapped = False
        playerHeight = G_SPRITE['player'].get_height()
        playery = playery + min(playerVelY, GROUNDY - playery - playerHeight)

        # move pipes to the left
        for upperPipe, lowerPipe in zip(upperPipes, lowerPipes):
            upperPipe['x'] += pipeVelX
            lowerPipe['x'] += pipeVelX

        # Add a new pipe when the first is about to cross the leftmost part of the screen
        if 0 < upperPipes[0]['x'] < 5:
            newpipe = getRandomPipe()
            upperPipes.append(newpipe[0])
            lowerPipes.append(newpipe[1])

        # if the pipe is out of the screen, remove it
        if upperPipes[0]['x'] < -G_SPRITE['pipe'][0].get_width():
            upperPipes.pop(0)
            lowerPipes.pop(0)

        # Lets blit our sprites now
        SCREEN.blit(G_SPRITE['background'], (0, 0))
        for upperPipe, lowerPipe in zip(upperPipes, lowerPipes):
            SCREEN.blit(G_SPRITE['pipe'][0], (upperPipe['x'], upperPipe['y']))
            SCREEN.blit(G_SPRITE['pipe'][1], (lowerPipe['x'], lowerPipe['y']))

        SCREEN.blit(G_SPRITE['base'], (basex, GROUNDY))
        SCREEN.blit(G_SPRITE['player'], (playerx, playery))
        myDigits = [int(x) for x in list(str(score))]
        width = 0
        for digit in myDigits:
            width += G_SPRITE['numbers'][digit].get_width()
        Xoffset = (S_WIDTH - width) / 2

        for digit in myDigits:
            SCREEN.blit(G_SPRITE['numbers'][digit], (Xoffset, S_HEIGHT * 0.12))
            Xoffset += G_SPRITE['numbers'][digit].get_width()
        pygame.display.update()
        FPSCLOCK.tick(FPS)

def isCollide(playerx, playery, upperPipes, lowerPipes):
    if playery > GROUNDY - 25 or playery < 0:
        G_SOUND['hit'].play()
        return True

    for pipe in upperPipes:
        pipeHeight = G_SPRITE['pipe'][0].get_height()
        if (playery < pipeHeight + pipe['y'] and abs(playerx - pipe['x']) < G_SPRITE['pipe'][0].get_width()):
            G_SOUND['hit'].play()
            return True

    for pipe in lowerPipes:
        if (playery + G_SPRITE['player'].get_height() > pipe['y']) and abs(playerx - pipe['x']) < \
                G_SPRITE['pipe'][0].get_width():
            G_SOUND['hit'].play()
            return True

    return False

def getRandomPipe():

    pipeHeight = G_SPRITE['pipe'][0].get_height()
    offset = S_HEIGHT / 3
    y2 = offset + random.randrange(0, int(S_HEIGHT - G_SPRITE['base'].get_height() - 1.2 * offset))
    pipeX = S_WIDTH + 10
    y1 = pipeHeight - y2 + offset
    pipe = [
        {'x': pipeX, 'y': -y1},  # upper Pipe
        {'x': pipeX, 'y': y2}  # lower Pipe
    ]
    return pipe

if __name__ == "__main__":
    
    pygame.init()  
    FPSCLOCK = pygame.time.Clock()
    pygame.display.set_caption('Flappy Duck')
    G_SPRITE['numbers'] = (
        pygame.image.load('gallery/sprites/0.png').convert_alpha(),
        pygame.image.load('gallery/sprites/1.png').convert_alpha(),
        pygame.image.load('gallery/sprites/2.png').convert_alpha(),
        pygame.image.load('gallery/sprites/3.png').convert_alpha(),
        pygame.image.load('gallery/sprites/4.png').convert_alpha(),
        pygame.image.load('gallery/sprites/5.png').convert_alpha(),
        pygame.image.load('gallery/sprites/6.png').convert_alpha(),
        pygame.image.load('gallery/sprites/7.png').convert_alpha(),
        pygame.image.load('gallery/sprites/8.png').convert_alpha(),
        pygame.image.load('gallery/sprites/9.png').convert_alpha(),
    )

    G_SPRITE['message'] = pygame.image.load('gallery/sprites/message.png').convert_alpha()
    G_SPRITE['base'] = pygame.image.load('gallery/sprites/base.png').convert_alpha()
    G_SPRITE['pipe'] = (pygame.transform.rotate(pygame.image.load(PIPE).convert_alpha(), 180),
                            pygame.image.load(PIPE).convert_alpha()
                            )

    # Game sounds
    G_SOUND['die'] = pygame.mixer.Sound('gallery/audio/die.wav')
    G_SOUND['hit'] = pygame.mixer.Sound('gallery/audio/hit.wav')
    G_SOUND['point'] = pygame.mixer.Sound('gallery/audio/point.wav')
    G_SOUND['swoosh'] = pygame.mixer.Sound('gallery/audio/swoosh.wav')
    G_SOUND['wing'] = pygame.mixer.Sound('gallery/audio/wing.wav')

    G_SPRITE['background'] = pygame.image.load(BACKGROUND).convert()
    G_SPRITE['player'] = pygame.image.load(PLAYER).convert_alpha()

    while True:
        welcomeScreen()  
        mainGame() 



